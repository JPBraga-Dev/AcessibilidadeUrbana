import React, { useState } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  ScrollView,
} from 'react-native';

import styles from './styles';

export default function App() {
  const [criterios, setCriterios] = useState([
    { id: 1, nome: 'Rampa de acesso', checked: true },
    { id: 2, nome: 'Calçada regular', checked: false },
    { id: 3, nome: 'Sinalização sonora', checked: false },
    { id: 4, nome: 'Piso tátil', checked: true },
    { id: 5, nome: 'Vaga para deficiente', checked: true },
    { id: 6, nome: 'Elevador/plataforma', checked: true },
    { id: 7, nome: 'Banheiro acessível', checked: true },
  ]);

  const [nota, setNota] = useState(3);

  function toggleItem(id) {
    const novaLista = criterios.map((item) =>
      item.id === id
        ? { ...item, checked: !item.checked }
        : item
    );

    setCriterios(novaLista);
  }

  return (
    <ScrollView style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <Text style={styles.headerText}>
          Avaliar Acessibilidade
        </Text>
      </View>

      {/* Informações */}
      <View style={styles.infoContainer}>
        <Text style={styles.localNome}>
          Shopping Ibirapuera
        </Text>

        <Text style={styles.localEndereco}>
          Estabelecimento • São Paulo - SP
        </Text>
      </View>

      {/* Checklist */}
      <Text style={styles.sectionTitle}>
        Checklist de Critérios
      </Text>

      {criterios.map((item) => (
        <TouchableOpacity
          key={item.id}
          style={styles.card}
          onPress={() => toggleItem(item.id)}
        >
          <View
            style={[
              styles.checkbox,
              item.checked && styles.checkboxAtivo,
            ]}
          >
            {item.checked && (
              <Text style={styles.checkText}>✓</Text>
            )}
          </View>

          <Text style={styles.cardText}>
            {item.nome}
          </Text>

          <Text style={styles.statusIcon}>
            {item.checked ? '✔' : '✘'}
          </Text>
        </TouchableOpacity>
      ))}

      {/* Nota */}
      <View style={styles.notaContainer}>
        <Text style={styles.notaText}>Nota geral</Text>

        <View style={styles.estrelas}>
          {[1, 2, 3, 4, 5].map((estrela) => (
            <TouchableOpacity
              key={estrela}
              onPress={() => setNota(estrela)}
            >
              <Text
                style={[
                  styles.estrela,
                  estrela <= nota
                    ? styles.estrelaAtiva
                    : styles.estrelaInativa,
                ]}
              >
                ★
              </Text>
            </TouchableOpacity>
          ))}
        </View>
      </View>

      {/* Botão */}
      <TouchableOpacity style={styles.botao}>
        <Text style={styles.botaoTexto}>
          SALVAR AVALIAÇÃO
        </Text>
      </TouchableOpacity>
    </ScrollView>
  );
}