import { StyleSheet } from 'react-native';

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F2F2F2',
  },

  header: {
    backgroundColor: '#1E8E5A',
    paddingTop: 50,
    paddingBottom: 15,
    paddingHorizontal: 15,
  },

  headerText: {
    color: '#FFF',
    fontSize: 20,
    fontWeight: 'bold',
  },

  infoContainer: {
    padding: 15,
  },

  localNome: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#222',
  },

  localEndereco: {
    marginTop: 5,
    color: '#777',
    fontSize: 14,
  },

  sectionTitle: {
    marginHorizontal: 15,
    marginBottom: 10,
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333',
  },

  card: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#FFF',
    marginHorizontal: 15,
    marginBottom: 10,
    padding: 12,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: '#DDD',
  },

  checkbox: {
    width: 22,
    height: 22,
    borderRadius: 6,
    borderWidth: 1,
    borderColor: '#AAA',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 10,
  },

  checkboxAtivo: {
    backgroundColor: '#1E8E5A',
    borderColor: '#1E8E5A',
  },

  checkText: {
    color: '#FFF',
    fontWeight: 'bold',
  },

  cardText: {
    flex: 1,
    fontSize: 15,
    color: '#333',
  },

  statusIcon: {
    fontSize: 16,
    color: '#999',
  },

  notaContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 15,
    marginHorizontal: 15,
  },

  notaText: {
    fontSize: 16,
    fontWeight: 'bold',
    marginRight: 10,
  },

  estrelas: {
    flexDirection: 'row',
  },

  estrela: {
    fontSize: 28,
    marginRight: 5,
  },

  estrelaAtiva: {
    color: '#FFC107',
  },

  estrelaInativa: {
    color: '#CCC',
  },

  botao: {
    backgroundColor: '#1E8E5A',
    margin: 15,
    padding: 16,
    borderRadius: 10,
    alignItems: 'center',
  },

  botaoTexto: {
    color: '#FFF',
    fontSize: 16,
    fontWeight: 'bold',
  },
});

export default styles;